from flask import Blueprint, render_template, request, redirect, url_for, session
from app.extensions import db
from app.models import Tarefa

main_bp = Blueprint('main', __name__)

@main_bp.route('/', methods=['GET', 'POST'])
def home():
    if 'logged_in' not in session:
        return redirect(url_for('auth.login'))

    # Recuperamos o ID do utilizador atual da sessão
    id_do_dono = session['user_id']

    if request.method == 'POST':
        titulo_enviado = request.form.get('tarefa')
        descr_enviada = request.form.get('descr')
       # if titulo_enviado:
       #     titulo_usuario = titulo_enviado
       # if descr_enviada:
       #    descr_usuario = int(descr_enviada)
        if titulo_enviado and descr_enviada:
            nova_tarefa = Tarefa(
                titulo=titulo_enviado, 
                descr=descr_enviada,
                dono_id=id_do_dono
                )
            db.session.add(nova_tarefa)
            db.session.commit()

    tarefas_banco = Tarefa.query.filter_by(dono_id=id_do_dono).all()

    return render_template(
        'index.html',
        titulo='TO DO LIST',
        tarefas=tarefas_banco,
    )

@main_bp.route('/sobre')
def about():
    return render_template('sobre.html')

@main_bp.route('/deletar/<int:id>')
def deletar_tarefa(id):
    if 'logged_in' not in session:
        return redirect(url_for('auth.login'))

    tarefa = Tarefa.query.get_or_404(id)
    db.session.delete(tarefa)
    db.session.commit()
    return redirect(url_for('main.home'))

@main_bp.route('/update/<int:id>', methods=['GET', 'POST'])
def update(id):
    if 'logged_in' not in session:
        return redirect(url_for('auth.login'))
    
    tarefa = Tarefa.query.get_or_404(id)

    if request.method == 'POST':
        titulo_atualizado = request.form.get('titulo')
        descr_atualizada = request.form.get('descr')
        if titulo_atualizado:
            tarefa.titulo = titulo_atualizado
        if descr_atualizada:
            tarefa.descr = int(descr_atualizada)
        db.session.commit()
        return redirect(url_for('main.home'))

    return render_template('update.html', tarefa=tarefa)