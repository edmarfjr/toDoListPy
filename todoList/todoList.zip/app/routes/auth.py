from flask import Blueprint, render_template, request, redirect, url_for, session
from app.extensions import db
from app.models import Conta

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        conta = Conta.query.filter_by(username=username).first()
        if conta and conta.senha == password:
            session['logged_in'] = True
            session['user_id'] = conta.id  # <--- Guardamos o ID do dono na sessão!
            session['user_name'] = conta.username
            return redirect(url_for('main.home'))
        else:
            return "Usuário ou senha incorretos!"
    return render_template('login.html')

@auth_bp.route('/logout')
def logout():
    # Remove a 'pulseira' da sessão
    session.pop('logged_in', None)
    return redirect(url_for('main.home'))

@auth_bp.route('/registrar', methods=['GET', 'POST'])
def registrar():
    if request.method == 'POST':
        user_digitado = request.form.get('username')
        senha_digitada = request.form.get('senha')

        # Verifica se já existe alguém com esse nome
        conta_existente = Conta.query.filter_by(username=user_digitado).first()
        
        if conta_existente:
            return "Esse nome de usuário já existe! Escolha outro."
        
        # Cria a nova conta
        nova_conta = Conta(username=user_digitado, senha=senha_digitada)
        db.session.add(nova_conta)
        db.session.commit()
        
        return "Conta criada com sucesso! <a href='/login'>Fazer Login</a>"

    return render_template('registrar.html')
